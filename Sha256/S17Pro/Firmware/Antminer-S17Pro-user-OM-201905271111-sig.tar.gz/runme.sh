#set -x
file=/tmp/$$
#if [ ! -f /etc/bitmain-pub.pem ]; then
#	echo "RUNME: SomeThing Err!">> /tmp/upgrade_result
#	exit 1
#fi


if [ ! -f cert.pem.sig ]; then
	echo "RUNME: Cannot Find Cert Signature!!!">> /tmp/upgrade_result
	exit 1
fi	
if [ ! -f cert.pem ]; then
	echo "RUNME: Cannot Find Cert!!!">> /tmp/upgrade_result
	exit 1
fi

if [ -e /etc/bitmain-pub.pem ]; then
	openssl dgst -sha256 -verify /etc/bitmain-pub.pem -signature  cert.pem.sig  cert.pem >/dev/null  2>&1
	vres=$?
	if [ $vres -eq 1 ]; then
		echo "RUNME: Cert Failed!!!" >> /tmp/upgrade_result
		exit 2
	fi
fi

if [ ! -f fileinfo.sig ]; then
		echo "RUNME: Cannot Find Signature!!!" >> /tmp/upgrade_result
		exit 1
fi
if [ ! -f fileinfo ]; then
	echo "RUNME: Cannot Find FileList!!!" >> /tmp/upgrade_result
	exit 1
fi	

openssl dgst -sha256 -verify cert.pem -signature  fileinfo.sig  fileinfo >/dev/null  2>&1
vres=$?
if [ $vres -eq 1 ]; then
	echo "RUNME: FileList Not Signtured!!!" >> /tmp/upgrade_result
	exit 2
fi	
md5sum -s -c fileinfo 
vres=$?
if [ $vres -eq 1 ]; then
	echo "RUNME: FileList Check Failed!!!" >> /tmp/upgrade_result
	exit 3
fi
if [ -e /etc/ant_version ]; then
	nVer=`cat version`
	oVer=`cat /etc/ant_version`

	if [ ${nVer} -lt ${oVer} ]; then
		echo "RUNME: Cannot Downgrade!!!" >> /tmp/upgrade_result
		exit 4
	fi	
fi
if [ -e uramdisk.image.gz ]; then
 		flash_erase /dev/mtd1 0x0 0x100 >/dev/null 2>&1
		nandwrite -p -s 0x0 /dev/mtd1 uramdisk.image.gz >/dev/null 2>&1
		if [ -e /dev/mtd4 ]; then
			flash_erase /dev/mtd4 0x0 0x100 >/dev/null 2>&1
			nandwrite -p -s 0x0 /dev/mtd4 uramdisk.image.gz >/dev/null 2>&1
		fi
fi

sync >/dev/null 2>&1
