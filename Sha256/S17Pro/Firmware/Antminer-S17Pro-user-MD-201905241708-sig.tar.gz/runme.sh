#set -x
file=/tmp/$$

if [ -e /etc/bitmain-pub.pem ]; then
	if [ ! -f fileinfo.sig ]; then
		echo "RUNME: Cannot Find Signature!!!" >> /tmp/upgrade_result
		exit 1
	fi
	openssl dgst -sha256 -verify /etc/bitmain-pub.pem -signature  fileinfo.sig  fileinfo >/dev/null  2>&1
	vres=$?
	if [ $vres -eq 1 ]; then
		echo "FileList Not Signtured!!!" >> /tmp/upgrade_result
		exit 2
	fi	
	md5sum -s -c fileinfo 
	vres=$?
	if [ $vres -eq 1 ]; then
		echo "FileList Check Failed!!!" >> /tmp/upgrade_result
		exit 3
	fi	
fi


if [ -e uramdisk.image.gz ]; then
 		flash_erase /dev/mtd1 0x0 0x100 >/dev/null 2>&1
		nandwrite -p -s 0x0 /dev/mtd1 uramdisk.image.gz >/dev/null 2>&1
		if [ -e /dev/mtd4 ]; then
			flash_erase /dev/mtd4 0x0 0x100 >/dev/null 2>&1
			nandwrite -p -s 0x0 /dev/mtd4 uramdisk.image.gz >/dev/null 2>&1
		fi
fi

sync >/dev/null 2>&1
